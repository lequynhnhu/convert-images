package me.code.image.opencv;

public enum MatchingStrategy {
	RATIO_TEST
}
