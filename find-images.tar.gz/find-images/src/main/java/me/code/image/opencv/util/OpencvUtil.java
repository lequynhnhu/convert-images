package me.code.image.opencv.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import javax.imageio.ImageIO;

import org.opencv.core.Core;
import org.opencv.core.Core.MinMaxLocResult;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.RotatedRect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.objdetect.Objdetect;
import org.opencv.utils.Converters;

public class OpencvUtil {

	public static void main(String[] args) {
		System.loadLibrary("opencv_java246");
		// new MatchingDemo().run(args[0], args[1], args[2], Imgproc.TM_CCOEFF);
	}

	public static void match() {
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		Mat source = null;
		Mat template = null;
		String filePath = "C:\\Users\\mesutpiskin\\Desktop\\Object Detection\\Template Matching\\Sample Image\\";
		source = Imgcodecs.imread(filePath + "kapadokya.jpg");
		template = Imgcodecs.imread(filePath + "balon.jpg");

		Mat outputImage = new Mat();
		int machMethod = Imgproc.TM_CCOEFF;

		Imgproc.matchTemplate(source, template, outputImage, machMethod);

		MinMaxLocResult mmr = Core.minMaxLoc(outputImage);
		Point matchLoc = mmr.maxLoc;

		Imgproc.rectangle(source, matchLoc, new Point(matchLoc.x + template.cols(), matchLoc.y + template.rows()),
				new Scalar(255, 255, 255));

		Imgcodecs.imwrite(filePath + "sonuc.jpg", source);
		System.out.println("İşlem tamamlandı.");
	}

	public void run(String inFile, String templateFile, String outFile, int match_method) {

		System.out.println("\nRunning Template Matching");
		Mat img = Highgui.imread(inFile);
		Mat templ = Highgui.imread(templateFile);
		// / Create the result matrix
		int result_cols = img.cols() - templ.cols() + 1;
		int result_rows = img.rows() - templ.rows() + 1;
		Mat result = new Mat(result_rows, result_cols, CvType.CV_32FC1);
		// / Do the Matching and Normalize
		Imgproc.matchTemplate(img, templ, result, match_method);
		Core.normalize(result, result, 0, 1, Core.NORM_MINMAX, -1, new Mat());
		// / Localizing the best match with minMaxLoc
		MinMaxLocResult mmr = Core.minMaxLoc(result);
		Point matchLoc;
		if (match_method == Imgproc.TM_SQDIFF || match_method == Imgproc.TM_SQDIFF_NORMED) {
			matchLoc = mmr.minLoc;
		} else {
			matchLoc = mmr.maxLoc;
		}
		// / Show me what you got
		// Core.rectangle(img, matchLoc, new Point(matchLoc.x + templ.cols(), matchLoc.y
		// + templ.rows()),
		// new Scalar(0, 255, 0));
		// Save the visualized detection.
		System.out.println("Writing " + outFile);
		Highgui.imwrite(outFile, img);
	}

	private static BufferedImage findTextRegion(BufferedImage src, Mat preproceeMat) {
		List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
		Imgproc.findContours(preproceeMat, contours, new Mat(), Imgproc.RETR_TREE, Imgproc.CHAIN_APPROX_SIMPLE);
		for (int i = 0; i < contours.size(); i++) {
			MatOfPoint2f newMtx = new MatOfPoint2f(contours.get(i).toArray());
			RotatedRect rotRect = Imgproc.minAreaRect(newMtx);
			Point[] vertices = new Point[4];
			rotRect.points(vertices);
			List<Point> rectArea = new ArrayList<Point>();
			for (int n = 0; n < 4; n++) {
				Point temp = new Point();
				temp.x = vertices[n].x;
				temp.y = vertices[n].y;
				rectArea.add(temp);
			}
			Mat rectMat = Converters.vector_Point_to_Mat(rectArea);
			double minRectArea = Imgproc.contourArea(rectMat);
			Point center = new Point();
			float radius[] = { 0 };
			Imgproc.minEnclosingCircle(newMtx, center, radius);
			if (Imgproc.contourArea(contours.get(i)) < 1000 || minRectArea < radius[0] * radius[0] * 1.57) {
				contours.remove(i);
			}
		}
		BufferedImage outImage = MatToBufferedImage(preproceeMat);
		return outImage;
	}

	public static BufferedImage MatToBufferedImage(Mat in) {
		MatOfByte mob = new MatOfByte();
		String fileExtension = ".png";
		Imgcodecs.imencode(fileExtension, in, mob);
		byte[] byteArray = mob.toArray();
		BufferedImage out = null;
		try {
			InputStream inputStream = new ByteArrayInputStream(byteArray);
			out = ImageIO.read(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return out;
	}

	private CascadeClassifier faceCascade;

	public List<Rect> detectFace(final Mat frame) {
		Mat grayFrame = new Mat();

		Imgproc.cvtColor(frame, grayFrame, Imgproc.COLOR_BGR2GRAY);

		// equalize the frame histogram to improve the result
		Imgproc.equalizeHist(grayFrame, grayFrame);

		// compute minimum face size (20% of the frame height, in our case)

		int minSize = 0;
		int height = grayFrame.rows();

		if (Math.round(height * 0.2f) > 0) {
			minSize = Math.round(height * 0.2f);
		}

		final MatOfRect detectedFacesRectangulars = new MatOfRect();

		this.faceCascade.detectMultiScale(grayFrame, detectedFacesRectangulars, 1.1, 1,
				Objdetect.CASCADE_DO_CANNY_PRUNING, new Size(minSize, minSize), grayFrame.size());

		return detectedFacesRectangulars.toList();
	}

	private void extractFace(Mat faceImage, Consumer<Mat> detectedFaceConsumer) {
		List<Rect> faces = detectFace(faceImage);

		if (faces.size() == 1) {
			Rect faceRect = faces.get(0);

			Rect cropFace = new Rect(faceRect.x, faceRect.y, faceRect.width, faceRect.height);

			detectedFaceConsumer.accept(new Mat(faceImage, cropFace));
		}
	}

	private CascadeClassifier mCascadeClassifier;
	private int mMinNeighbors;
	private float mRelativeObjectWidth;
	private float mRelativeObjectHeight;

	public Rect[] detectObject(Mat gray, MatOfRect object) {
		mCascadeClassifier.detectMultiScale(gray, object, 1.1, mMinNeighbors, Objdetect.CASCADE_SCALE_IMAGE,
				getSize(gray, mRelativeObjectWidth, mRelativeObjectHeight), gray.size());

		return object.toArray();
	}

	private Size getSize(Mat gray, float relativeObjectWidth, float relativeObjectHeight) {
		Size size = gray.size();
		int cameraWidth = gray.cols();
		int cameraHeight = gray.rows();
		int width = Math.round(cameraWidth * relativeObjectWidth);
		int height = Math.round(cameraHeight * relativeObjectHeight);
		size.width = 0 >= width ? 0 : (cameraWidth < width ? cameraWidth : width); // width [0, cameraWidth]
		size.height = 0 >= height ? 0 : (cameraHeight < height ? cameraHeight : height); // height [0, cameraHeight]
		return size;
	}

	public Mat[] snipFace(String image, Size size) {

		Mat matImage = Highgui.imread(image, Highgui.IMREAD_UNCHANGED);

		Rect[] rectFace = detectFaceNew(matImage);
		int rectFaceLength = rectFace.length;

		Mat[] matFace = new Mat[rectFaceLength];

		for (int i = 0; i < rectFaceLength; i++) {

			matFace[i] = matImage.submat(rectFace[i]);
			Imgproc.resize(matFace[i], matFace[i], size);

			// Highgui.imwrite(image.substring(0,
			// image.length()-4)+"Snipped"+i+image.substring(image.length()-4), matFace[i]);
		}

		return matFace;
	}

	private Rect[] detectFaceNew(Mat matImage) {

		MatOfRect faces = new MatOfRect();
		// C:\Users\admin\Desktop\My_Java_Programs\ObjectRecognition\resource\data
		String HumanFace4 = "src/res/knowledge/haarcascade_frontalface_alt.xml";

		CascadeClassifier cascadeClassifier = new CascadeClassifier(HumanFace4);

		cascadeClassifier.detectMultiScale(matImage, faces, 1.1, 10, Objdetect.CASCADE_DO_CANNY_PRUNING,
				new Size(20, 20), matImage.size());

		// System.out.println(faces.dump());///test

		return faces.toArray();
	}
}
