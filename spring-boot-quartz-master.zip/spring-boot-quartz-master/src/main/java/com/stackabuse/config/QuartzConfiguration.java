package com.stackabuse.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.stackabuse.entity.quartz.SchedulerJobInfo;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.stackabuse.repository.quartz", entityManagerFactoryRef = "quartzEntityManagerFactory", transactionManagerRef = "quartzTransactionManager")
public class QuartzConfiguration {

	@Bean(name = "quartzDataSourceProperties")
	@Primary
	@ConfigurationProperties("app.datasource.quartz")
	public DataSourceProperties quartzDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean(name = "quartzDataSource")
	@Primary
	@ConfigurationProperties("app.datasource.quartz.configuration")
	public DataSource quartzDataSource() {
		return quartzDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Primary
	@Bean(name = "quartzEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean quartzEntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(quartzDataSource()).packages(SchedulerJobInfo.class).persistenceUnit("quartz").build();
	}

	@Primary
	@Bean(name = "quartzTransactionManager")
	public PlatformTransactionManager quartzTransactionManager(
			final @Qualifier("quartzEntityManagerFactory") LocalContainerEntityManagerFactoryBean quartzEntityManagerFactory) {
		return new JpaTransactionManager(quartzEntityManagerFactory.getObject());
	}
}
