package com.stackabuse.entity.lookup;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Entity
@Table(name = "item")
public class ItemEntity {

	@Id
	private String id;

	private String itemName;
}
