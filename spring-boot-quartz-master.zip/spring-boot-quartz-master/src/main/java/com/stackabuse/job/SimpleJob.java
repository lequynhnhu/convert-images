package com.stackabuse.job;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.stackabuse.repository.lookup.LookupRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SimpleJob extends QuartzJobBean {

	@Autowired
	private LookupRepository lookupRepository;

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		log.info("SimpleJob Start................");
		
		List<?> list = lookupRepository.getLookupData("item");
		System.out.println("ddddd:" + list.size());
		
		log.info("SimpleJob End................");
	}
}
