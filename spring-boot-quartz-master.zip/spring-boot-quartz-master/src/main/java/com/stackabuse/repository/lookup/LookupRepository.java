package com.stackabuse.repository.lookup;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 */
@Repository
public class LookupRepository {

	@PersistenceContext(unitName = "lookup")
	private EntityManager entityManager;
	
	@Value("${app.datasource.lookup.schema}")
	private String schema;

	@Transactional("lookupTransactionManager")
	public List<Map<String, Object>> getLookupData(String tableName) {
		String sql = String.format("SELECT a.* FROM %s.%s a", schema, tableName);
		Query q = entityManager.createNativeQuery(sql);
		return  q.getResultList();
	}
}
